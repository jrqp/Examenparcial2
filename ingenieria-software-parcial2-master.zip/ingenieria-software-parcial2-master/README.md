# ingenieria-software-parcial2
Proyecto para segundo examen parcial.
